<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\MainCategory;
use Illuminate\Http\Request;

class CategoryController extends Controller
{

    public function index(){
        $categories=MainCategory::all();
        return view('category.index',compact('categories'));
    }

    public function changeStatus(Request $request)
    {
        $category = MainCategory::findOrFail($request->category_id);
        $category->status = $request->status;
        $category->save();

        return response()->json(['success' => 'Status updated successfully!']);
    }

}
